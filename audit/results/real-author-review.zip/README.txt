Digital Product Studio — RELEASE AUDIT ONLY — Emergency Expense Planning
Unzip the complete folder and open START-HERE.html. Keep the folder structure intact.
Start with resources/executive-summary.html for a quick-start overview, then open book/executive-ebook.html.
The e-book, chapter readers, worksheets, companion HTML and source reading room work offline. External source links require internet access. Print HTML files from your browser to save PDFs.
Status: Author review required; do not distribute as a completed buyer product.
Images are embedded in the book and provided separately when rights metadata is present.
No paid source books, videos, external spreadsheets or licensed source documents are implied unless actually supplied.
