# Build an emergency-expense planning ledger — Practice Worksheet

## Learning objective
Create and review a dated ledger while separating reported survey context from original instructions.

## Key topics covered
- [ ] Evidence boundary
- [ ] Dated ledger
- [ ] Original worked example
- [ ] Review

## Worked scenarios to compare
- Clearly fictional $120 repair with $50 set aside

## Before reading
- What baseline metric or current constraint am I bringing to this chapter?
- What concrete decision do I need to make after completing it?

## Evidence & application notebook
| Key insight / method from chapter | Reference ID & locator | How it applies to my situation | Next concrete action |
|---|---|---|---|
| | | | |
| | | | |

## Apply the method: Completed expense ledger
1. Describe the real situation or dataset where you will apply this chapter.
2. Record your starting baseline and constraints before making changes.
3. Execute the step-by-step framework from the chapter and capture your outputs.
4. Compare your output against the completion standard below.

## Completion check
Every row contains confirmed inputs or explicit unknowns.

## Supporting sources mapped to this chapter
- [REF-FED-SHED-2025] Federal Reserve Board issues Economic Well-Being of U.S. Households in 2025 report

## Reflection
- What worked reliably, and what evidence or result confirms it?
- What friction or edge case came up?
- Which step should I carry into next week's routine?
