# Repeatable Client & Project SOP Standardization — Practice Worksheet

## Learning objective
Convert complex recurring deliverables into checklist-driven standard operating procedures.

## Key topics covered
- [ ] Core framework & evidence
- [ ] Step-by-step worked example
- [ ] Practical execution checklist

## Before reading
- What baseline metric or current constraint am I bringing to this chapter?
- What concrete decision do I need to make after completing it?

## Evidence & application notebook
| Key insight / method from chapter | Reference ID & locator | How it applies to my situation | Next concrete action |
|---|---|---|---|
| | | | |
| | | | |

## Apply the method: Reusable 1-Page SOP Builder
1. Describe the real situation or dataset where you will apply this chapter.
2. Record your starting baseline and constraints before making changes.
3. Execute the step-by-step framework from the chapter and capture your outputs.
4. Compare your output against the completion standard below.

## Completion check
Publish and test 2 core SOP checklists on active work.

## Reflection
- What worked reliably, and what evidence or result confirms it?
- What friction or edge case came up?
- Which step should I carry into next week's routine?
